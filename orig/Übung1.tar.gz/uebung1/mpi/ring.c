/*==============================================================================
  
   Purpose          :
   Author           : Rudolf Berrendorf
                      Computer Science Department
                      Bonn-Rhein-Sieg University of Applied Sciences
	              53754 Sankt Augustin, Germany
                      rudolf.berrendorf@h-brs.de
  
==============================================================================*/

#include <stdio.h>
#include <stdlib.h>
#include <libFHBRS.h>

//==============================================================================

int main(int argc, char **argv)
{

  return 0;
}

/*============================================================================*
 *                             that's all folks                               *
 *============================================================================*/
